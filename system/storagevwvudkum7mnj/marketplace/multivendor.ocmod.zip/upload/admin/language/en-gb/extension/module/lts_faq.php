<?php
// Heading
$_['heading_title']    = 'Product FAQ';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Success: You have modified Product FAQ module!';
$_['text_edit']        = 'Edit Product FAQ Module';

// Entry
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify Product FAQ module!';