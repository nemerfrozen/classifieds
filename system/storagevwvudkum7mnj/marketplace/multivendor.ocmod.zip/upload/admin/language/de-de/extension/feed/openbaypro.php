<?php
/**
 * @version		$Id: openbaypro.php 6115 2021-03-14 10:15:06Z mic $
 * @package		Language Translation German Backend
 * @author		mic - https://osworx.net
 * @copyright	2021 OSWorX
 * @license		GPL - www.gnu.org/copyleft/gpl.html
 *
 * note: only OC < 3.1
 */

// Heading
$_['heading_title']		= 'OpenBay Pro';