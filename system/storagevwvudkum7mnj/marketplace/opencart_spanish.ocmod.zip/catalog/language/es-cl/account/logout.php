<?php

$_['heading_title'] = 'Cierre de sesión de la cuenta';
$_['text_message'] = '<p>Has cerrado la sesión de tu cuenta. Ahora es seguro abandonar el computador.</p><p>Se ha guardado tu carro de compras, los artículos dentro de él se restaurarán cada vez que vuelvas a iniciar sesión con tu cuenta.</p>';
$_['text_account'] = 'Cuenta';
$_['text_logout'] = 'Cerrar sesión';
