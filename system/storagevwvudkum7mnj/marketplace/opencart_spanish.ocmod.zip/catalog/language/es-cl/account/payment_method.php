<?php

$_['heading_title'] = 'Métodos de pago';
$_['text_account'] = 'Cuenta';
$_['text_payment_method'] = 'Entradas de método de pago';
$_['text_success'] = 'Se ha eliminado exitosamente tu método de pago';
$_['text_no_results'] = 'No tienes métodos de pago en tu cuenta.';
$_['column_payment_method'] = 'Método de pago';
$_['column_type'] = 'Tipo';
$_['column_date_expire'] = 'Fecha de expiración';
$_['column_action'] = 'Acción';
$_['error_payment_method'] = 'Aviso: ¡No se pudo encontrar el método de pago!';
