<?php

$_['heading_title'] = 'Mi lista de deseos';
$_['text_account'] = 'Cuenta';
$_['text_instock'] = 'Disponible';
$_['text_wishlist'] = 'Lista de deseos (%s)';
$_['text_login'] = '¡Debes <a href="%s">iniciar sesión</a> o <a href="%s">crear una cuenta</a> para guardar <a href="%s">%s</a> en tu <a href="%s">lista de deseos</a>!';
$_['text_success'] = 'Éxito: ¡Has agregado <a href="%s">%s</a> a tu <a href="%s">lista de deseos</a>!';
$_['text_remove'] = 'Éxito: ¡Has quitado un producto de tu lista de deseos!';
$_['text_no_results'] = 'Tu lista de deseos está vacía.';
$_['column_image'] = 'Imagen';
$_['column_name'] = 'Nombre de producto';
$_['column_model'] = 'Modelo';
$_['column_stock'] = 'Existencias';
$_['column_price'] = 'Precio por unidad';
$_['column_action'] = 'Acción';
$_['error_product'] = 'Aviso: ¡No se pudo encontrar el producto!';
