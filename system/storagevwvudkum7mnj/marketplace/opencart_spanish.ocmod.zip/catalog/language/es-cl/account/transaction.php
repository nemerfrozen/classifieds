<?php

$_['heading_title'] = 'Tus transacciones';
$_['column_date_added'] = 'Fecha de alta';
$_['column_description'] = 'Descripción';
$_['column_amount'] = 'Monto (%s)';
$_['text_account'] = 'Cuenta';
$_['text_transaction'] = 'Tus transacciones';
$_['text_total'] = 'Tu saldo actual es de:';
$_['text_no_results'] = '¡No tienes transacciones!';
