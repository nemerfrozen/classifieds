<?php

$_['heading_title'] = 'Descargas';
$_['text_account'] = 'Cuenta';
$_['text_downloads'] = 'Descargas';
$_['text_no_results'] = '¡No has hecho pedidos descargables anteriormente!';
$_['column_order_id'] = 'ID de pedido';
$_['column_name'] = 'Nombre';
$_['column_size'] = 'Tamaño';
$_['column_date_added'] = 'Fecha de alta';
$_['error_not_found'] = 'Error: ¡No se pudo encontrar el archivo %s!';
$_['error_headers_sent'] = 'Error: ¡Los encabezados ya se enviaron!';
