<?php

$_['heading_title'] = 'Seguimiento de afiliados';
$_['text_account'] = 'Cuenta';
$_['text_description'] = 'Para asegurarnos de que recibas los pagos por los referidos que nos envíes, necesitamos hacer seguimiento del referido al poner un código de seguimiento en las URL que nos enlacen. Puedes usar las siguientes herramientas para generar enlaces al sitio web de %s.';
$_['entry_code'] = 'Tu código de seguimiento';
$_['entry_generator'] = 'Generador de enlaces de seguimiento';
$_['entry_link'] = 'Enlace de seguimiento';
$_['help_generator'] = 'Comienza a escribir el nombre de un producto al que quisieras enlazar';
