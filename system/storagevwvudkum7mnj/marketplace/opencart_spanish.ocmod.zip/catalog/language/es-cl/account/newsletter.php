<?php

$_['heading_title'] = 'Suscripción al boletín';
$_['text_account'] = 'Cuenta';
$_['text_newsletter'] = 'Boletín informativo';
$_['text_success'] = 'Éxito: ¡La suscripción al boletín se ha actualizado exitosamente!';
$_['entry_newsletter'] = 'Suscribir';
