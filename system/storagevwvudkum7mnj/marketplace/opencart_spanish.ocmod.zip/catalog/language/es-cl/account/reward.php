<?php

$_['heading_title'] = 'Tus puntos';
$_['column_date_added'] = 'Fecha de alta';
$_['column_description'] = 'Descripción';
$_['column_points'] = 'Puntos';
$_['text_account'] = 'Cuenta';
$_['text_reward'] = 'Puntos';
$_['text_total'] = 'La cantidad total de puntos que tienes es de:';
$_['text_no_results'] = '¡No tienes puntos!';
