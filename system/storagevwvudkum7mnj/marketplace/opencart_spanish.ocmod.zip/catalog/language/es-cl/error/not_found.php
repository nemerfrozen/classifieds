<?php

$_['heading_title'] = '¡No se pudo encontrar la página que solicitaste!';
$_['text_error'] = 'No se puede encontrar la página que solicitaste.';
