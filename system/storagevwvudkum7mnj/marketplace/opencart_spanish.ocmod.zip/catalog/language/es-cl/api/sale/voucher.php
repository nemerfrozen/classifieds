<?php

$_['text_cart'] = 'Éxito: ¡Has modificado tu carro de compras!';
$_['text_for'] = 'Tarjeta de regalo %s para %s';
$_['text_success'] = 'Éxito: ¡Se ha aplicado el descuento de tu tarjeta de regalo!';
$_['text_remove'] = 'Éxito: ¡Se ha quitado el descuento de tu tarjeta de regalo!';
$_['error_voucher'] = 'Aviso: ¡La tarjeta de regalo no es válida o su saldo ya ha sido utilizado!';
$_['error_to_name'] = '¡El nombre de destinatario debe tener entre 1 y 64 caracteres!';
$_['error_from_name'] = '¡Tu nombre debe tener entre 1 y 64 caracteres!';
$_['error_email'] = '¡La dirección de correo electrónico no parece ser válida!';
$_['error_theme'] = '¡Debes seleccionar un tema!';
$_['error_amount'] = '¡El monto debe ser entre %s y %s!';
