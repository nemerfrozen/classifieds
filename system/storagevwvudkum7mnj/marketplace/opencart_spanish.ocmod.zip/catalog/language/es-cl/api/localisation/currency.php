<?php

$_['text_success'] = 'Éxito: ¡Se ha cambiado tu divisa!';
$_['error_currency'] = 'Aviso: ¡No se pudo encontrar la divisa!';
