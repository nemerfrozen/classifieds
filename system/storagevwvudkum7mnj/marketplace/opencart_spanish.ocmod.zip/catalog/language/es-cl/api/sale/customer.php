<?php

$_['text_success'] = 'Has modificado exitosamente los clientes';
$_['error_customer'] = 'Aviso: ¡No se pudo encontrar el cliente!';
$_['error_customer_group'] = '¡El grupo de clientes no parece ser válido!';
$_['error_firstname'] = '¡El nombre debe tener entre 1 y 32 caracteres!';
$_['error_lastname'] = '¡Los apellidos deben tener entre 1 y 32 caracteres!';
$_['error_email'] = '¡La dirección de correo electrónico no parece ser válida!';
$_['error_telephone'] = '¡El teléfono debe tener entre 3 y 32 caracteres!';
$_['error_custom_field'] = '¡Se requiere %s!';
$_['error_regex'] = '¡%s no es una entrada válida!';
