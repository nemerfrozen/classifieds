<?php

$_['text_success'] = 'Éxito: ¡Se ha establecido el método de envío!';
$_['error_shipping_address'] = 'Aviso: ¡Se requiere la dirección de envío!';
$_['error_shipping_method'] = 'Aviso: ¡Se requiere el medio de envío!';
$_['error_no_shipping'] = 'Aviso: ¡Ninguna opción de envío está disponible!';
$_['error_shipping'] = 'Aviso: ¡No hay productos que requieran envío!';
