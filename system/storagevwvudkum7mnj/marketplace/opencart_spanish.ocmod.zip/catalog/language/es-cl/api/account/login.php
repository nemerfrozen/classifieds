<?php

$_['text_success'] = 'Éxito: ¡Se inició exitosamente la sesión de la API!';
$_['error_permission'] = 'Aviso: ¡No tienes permiso para acceder a la API!';
$_['error_key'] = 'Aviso: ¡Clave incorrecta de la API!';
$_['error_ip'] = 'Aviso: ¡No se permite a tu dirección IP %s el acceso a esta API!';
