<?php

$_['text_success'] = 'Éxito: ¡Se ha aplicado el cupón de descuento!';
$_['text_remove'] = 'Éxito: ¡Se ha removido tu cupón de descuento!';
$_['error_coupon'] = 'Aviso: ¡El cupón podría no ser válido, expiró o alcanzó su límite de uso!';
