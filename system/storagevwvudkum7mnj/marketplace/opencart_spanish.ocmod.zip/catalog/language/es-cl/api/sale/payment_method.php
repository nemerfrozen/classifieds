<?php

$_['text_success'] = 'Éxito: ¡El método de pago ha sido establecido!';
$_['error_payment_address'] = 'Aviso: ¡Se requiere la dirección de pago!';
$_['error_payment_method'] = 'Aviso: ¡Se requiere el método de pago!';
$_['error_no_payment'] = 'Aviso: ¡No hay opciones de pago disponibles!';
$_['error_product'] = 'Aviso: ¡Se requieren los productos!';
