<?php

$_['text_success'] = 'Éxito: ¡Has modificado tu carro de compras!';
$_['text_subscription'] = 'Suscripción';
$_['text_subscription_trial'] = '%s cada %d %s(s) para %d pago(s) entonces ';
$_['text_subscription_duration'] = '%s cada %d %s(s) para %d pago(s)';
$_['text_subscription_cancel'] = '%s cada %d %s(s) hasta que se cancele';
$_['text_day'] = 'día';
$_['text_week'] = 'semana';
$_['text_semi_month'] = 'mitad de mes';
$_['text_month'] = 'mes';
$_['text_year'] = 'año';
$_['text_for'] = 'Tarjeta de regalo %s para %s';
$_['error_stock'] = '¡Los productos marcados con *** no están disponibles en la cantidad deseada o no hay existencias!';
$_['error_minimum'] = '¡El monto mínimo del pedido para %s es de %s!';
$_['error_store'] = '¡No se puede comprar el producto en la tienda que has elegido!';
$_['error_required'] = '¡Se requiere %s!';
$_['error_product'] = 'Aviso: ¡No se pudo encontrar el producto!';
$_['error_subscription'] = '¡Por favor selecciona un plan de suscripción!';
