<?php

$_['text_success'] = 'Éxito: ¡El descuento con tus puntos ha sido aplicado!';
$_['text_remove'] = 'Éxito: ¡Se ha quitado el descuento con tus puntos de recompensa!';
$_['error_reward'] = 'Aviso: ¡Por favor ingresa la cantidad de puntos a utilizar!';
$_['error_points'] = 'Aviso: ¡No tienes %s puntos!';
$_['error_maximum'] = 'Aviso: ¡El número máximo de puntos que se pueden aplicar es de %s!';
