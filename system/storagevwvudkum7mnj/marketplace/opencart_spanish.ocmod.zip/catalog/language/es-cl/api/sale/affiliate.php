<?php

$_['text_success'] = 'Éxito: ¡Se aplicará comisión de afiliado a este pedido!';
$_['text_remove'] = 'Éxito: ¡Se ha removido tu comisión de afiliado!';
$_['error_affiliate'] = 'Aviso: ¡No se pudo encontrar el afiliado!';
