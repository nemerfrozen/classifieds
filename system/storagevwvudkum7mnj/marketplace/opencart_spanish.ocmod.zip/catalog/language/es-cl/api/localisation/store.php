<?php

$_['text_success'] = 'Éxito: ¡Se ha cambiado la tienda!';
$_['error_store'] = 'Aviso: ¡No se pudo encontrar la tienda!';
