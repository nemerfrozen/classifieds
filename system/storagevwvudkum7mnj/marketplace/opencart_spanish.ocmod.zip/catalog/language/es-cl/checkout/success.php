<?php

$_['heading_title'] = '¡Tu pedido ha sido realizado!';
$_['text_basket'] = 'Carro de compras';
$_['text_checkout'] = 'Pagar';
$_['text_success'] = 'Éxito';
$_['text_customer'] = '<p>¡Tu pedido se ha procesado exitosamente!</p><p>Puedes ver el historial de tus pedidos en la página de <a href="%s">mi cuenta</a> y haciendo clic en <a href="%s">historial</a>.</p><p>Si tu compra tuviera una descarga asociada, puedes ir a la página de <a href="%s">descargas</a> de la cuenta para verlas.</p><p>Por favor haz llegar cualquier pregunta que tengas al <a href="%s">dueño de la tienda</a>.</p><p>¡Gracias por comprar en línea con nosotros!</p>';
$_['text_guest'] = '<p>¡Se ha procesado tu pedido exitosamente!</p><p>Puedes realizar cualquier consulta al <a href="%s">dueño de la tienda</a>.</p><p>¡Gracias por comprar en línea con nosotros!</p>';
