<?php

$_['heading_title'] = 'Pagar';
$_['text_cart'] = 'Carro de compras';
