<?php

$_['heading_title'] = 'Método de envío';
$_['text_shipping_method'] = 'Opciones de método de despacho';
$_['text_shipping'] = 'Por favor selecciona el método de envío preferido para usar en este pedido.';
$_['text_success'] = 'Éxito: ¡Has cambiado el método de envío!';
$_['entry_shipping_method'] = 'Elige el método de envío...';
$_['error_customer'] = '¡Se requiere el cliente!';
$_['error_payment_address'] = '¡Se requiere la dirección de facturación!';
$_['error_shipping_address'] = '¡Se requiere la dirección de envío!';
$_['error_shipping_method'] = '¡Se requiere el método de envío!';
$_['error_no_shipping'] = 'Aviso: ¡No hay opciones de envío disponibles! ¡Por favor <a href="%s">contáctanos</a> para recibir ayuda!';
