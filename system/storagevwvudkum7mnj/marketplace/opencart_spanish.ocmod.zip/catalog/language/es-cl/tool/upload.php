<?php

$_['text_upload'] = '¡Tu archivo fue exitosamente cargado!';
$_['error_filename'] = '¡El nombre de archivo debe tener entre 3 y 64 caracteres!';
$_['error_file_type'] = '¡El tipo de archivo no es válido!';
$_['error_upload'] = '¡Se requiere el archivo a cargar!';
