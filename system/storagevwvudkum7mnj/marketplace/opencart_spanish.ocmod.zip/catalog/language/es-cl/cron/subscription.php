<?php

$_['text_success'] = 'Éxito: ¡Se ha renovado exitosamente el perfil de suscripción!';
$_['error_language'] = 'Aviso: ¡No se pudo encontrar la extensión del método de pago!';
$_['error_customer'] = 'Aviso: ¡No se pudo encontrar la extensión del método de pago!';
$_['error_product'] = 'Aviso: ¡No se pudo encontrar la extensión del método de pago!';
$_['error_shipping_address'] = 'Aviso: ¡No se pudo encontrar la extensión del método de pago!';
$_['error_shipping_method'] = 'Aviso: ¡No se pudo encontrar el método de envío %s!';
$_['error_payment_address'] = 'Aviso: ¡No se pudo encontrar la extensión del método de pago!';
$_['error_payment_method'] = 'Aviso: ¡No se pudo encontrar el método de pago %s!';
$_['error_extension'] = 'Aviso: ¡No se pudo encontrar la extensión del método de pago!';
$_['error_recurring'] = 'Aviso: ¡El método de pago no tiene el método de pago recurrente!';
