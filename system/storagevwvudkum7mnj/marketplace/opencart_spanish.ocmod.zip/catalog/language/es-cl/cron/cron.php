<?php

$_['text_success'] = 'Éxito: ¡Has ejecutado %s trabajos Cron!';
$_['error_permission'] = 'Aviso: ¡No tienes permiso para modificar trabajos Cron!';
