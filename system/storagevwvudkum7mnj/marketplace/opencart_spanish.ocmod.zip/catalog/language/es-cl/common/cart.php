<?php

$_['text_items'] = '%s artículo(s) - %s';
$_['text_points'] = 'Puntos';
$_['text_subscription'] = 'Suscripción';
$_['text_subscription_trial'] = '%s cada %d %s(s) para %d pago(s) entonces ';
$_['text_subscription_duration'] = '%s cada %d %s(s) para %d pago(s)';
$_['text_subscription_cancel'] = '%s cada %d %s(s) hasta que se cancele';
$_['text_day'] = 'día';
$_['text_week'] = 'semana';
$_['text_semi_month'] = 'mitad de mes';
$_['text_month'] = 'mes';
$_['text_year'] = 'año';
$_['text_no_results'] = '¡Tu carro de compras está vacío!';
$_['text_cart'] = 'Ver el carro';
$_['text_checkout'] = 'Pagar';
$_['error_product'] = 'Aviso: ¡No se pudo encontrar el producto!';
