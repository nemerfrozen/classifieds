<?php

$_['text_currency'] = 'Divisa';
