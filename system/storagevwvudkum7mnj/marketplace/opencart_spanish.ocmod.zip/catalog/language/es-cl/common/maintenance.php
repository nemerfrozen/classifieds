<?php

$_['heading_title'] = 'Mantenimiento';
$_['text_maintenance'] = 'Mantenimiento';
$_['text_message'] = '<h1 style="text-align:center;">Estamos realizando trabajos programados. <br/>Volveremos tan pronto como sea posible. Por favor vuelve más tarde.</h1>';
