<?php

$_['text_wishlist'] = 'Lista de deseos (%s)';
$_['text_shopping_cart'] = 'Carro de compras';
$_['text_account'] = 'Mi cuenta';
$_['text_register'] = 'Registro';
$_['text_login'] = 'Iniciar sesión';
$_['text_order'] = 'Historial de pedidos';
$_['text_transaction'] = 'Transacciones';
$_['text_download'] = 'Descargas';
$_['text_logout'] = 'Cerrar sesión';
$_['text_checkout'] = 'Pagar';
