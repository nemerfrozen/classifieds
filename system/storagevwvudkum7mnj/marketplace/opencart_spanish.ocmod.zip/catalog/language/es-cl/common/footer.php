<?php

$_['text_information'] = 'Información';
$_['text_blog'] = 'Blog';
$_['text_service'] = 'Servicio al cliente';
$_['text_extra'] = 'Extras';
$_['text_contact'] = 'Contáctanos';
$_['text_return'] = 'Devoluciones';
$_['text_sitemap'] = 'Mapa del sitio';
$_['text_gdpr'] = 'RGPD';
$_['text_manufacturer'] = 'Marcas';
$_['text_voucher'] = 'Tarjetas de regalo';
$_['text_affiliate'] = 'Afiliados';
$_['text_special'] = 'Ofertas especiales';
$_['text_account'] = 'Mi cuenta';
$_['text_order'] = 'Historial de pedidos';
$_['text_wishlist'] = 'Lista de deseos';
$_['text_newsletter'] = 'Boletín informativo';
$_['text_powered'] = 'Impulsado por <a href="https://www.opencart.com">OpenCart</a><br/> %s &copy; %s';
