<?php

$_['text_success'] = '¡Gracias por dejarnos saber tu elección!';
$_['text_cookie'] = 'Este sitio web usa cookies. Para más información <a href="%s" class="alert-link modal-link">haz clic aquí</a>.';
$_['button_agree'] = 'Sí, ¡está bien!';
$_['button_disagree'] = '¡No, gracias!';
