<?php

$_['text_price'] = 'Precio:';
$_['text_tax'] = 'Sin impuestos:';
