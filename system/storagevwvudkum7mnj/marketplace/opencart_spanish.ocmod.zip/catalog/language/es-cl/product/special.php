<?php

$_['heading_title'] = 'Ofertas especiales';
$_['text_no_results'] = 'No hay productos de ofertas especiales para mostrar.';
$_['text_compare'] = 'Comparador de productos (%s)';
$_['text_sort'] = 'Ordenar por';
$_['text_default'] = 'Predeterminado';
$_['text_name_asc'] = 'Nombre (A - Z)';
$_['text_name_desc'] = 'Nombre (Z - A)';
$_['text_price_asc'] = 'Precio (Bajo &gt; Alto)';
$_['text_price_desc'] = 'Precio (de mayor a menor)';
$_['text_rating_asc'] = 'Calificación (la más baja)';
$_['text_rating_desc'] = 'Calificación (la más alta)';
$_['text_model_asc'] = 'Modelo (A - Z)';
$_['text_model_desc'] = 'Modelo (Z - A)';
$_['text_limit'] = 'Mostrar';
