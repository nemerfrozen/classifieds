<?php

$_['text_subject'] = '%s - Comisión del afiliado';
$_['text_received'] = '¡Felicitaciones! Has recibido un pago de comisión del programa de afiliados de %s';
$_['text_amount'] = 'Has recibido:';
$_['text_total'] = 'El monto total de tu comisión ahora es:';
