<?php

$_['text_subject'] = '%s - Pedido %s - Suscripción anulada';
$_['text_received'] = 'Tienes una suscripción anulada.';
$_['text_orders_id'] = 'ID de pedido:';
$_['text_subscription_id'] = 'ID de suscripción';
$_['text_date_added'] = 'Fecha de alta:';
$_['text_subscription_status'] = 'Estado de la suscripción:';
$_['text_comment'] = 'Los comentarios para tu suscripción son:';
$_['text_canceled'] = 'Éxito: ¡Se ha anulado el perfil de suscripción!';
