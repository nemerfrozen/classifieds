<?php

$_['text_subject'] = '%s - Comentario del producto';
$_['text_waiting'] = 'Tienes un nuevo comentario de producto esperando.';
$_['text_product'] = 'Producto:';
$_['text_reviewer'] = 'Revisor:';
$_['text_rating'] = 'Calificación:';
$_['text_review'] = 'Texto del comentario:';
