<?php

$_['text_subject'] = '%s - Solicitud para restablecer la contraseña';
$_['text_greeting'] = 'Se solicitó una nueva contraseña para la cuenta de cliente %s.';
$_['text_change'] = 'Para restablecer tu contraseña, haz clic en el siguiente enlace:';
$_['text_ip'] = 'La dirección IP usada para hacer esta solicitud fue:';
$_['button_reset'] = 'Restablecer contraseña';
