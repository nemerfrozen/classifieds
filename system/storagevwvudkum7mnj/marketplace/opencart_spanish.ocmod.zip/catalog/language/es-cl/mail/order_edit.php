<?php

$_['text_subject'] = '%s - Actualización del pedido %s';
$_['text_order_id'] = 'ID de pedido:';
$_['text_date_added'] = 'Fecha de alta:';
$_['text_order_status'] = 'Tu pedido ha sido actualizado al siguiente estado:';
$_['text_comment'] = 'Los comentarios para tu pedido son:';
$_['text_link'] = 'Para ver tu pedido, haz clic en el siguiente enlace:';
$_['text_footer'] = 'Por favor responde a este mensaje si tienes alguna pregunta.';
