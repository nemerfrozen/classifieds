<?php

$_['text_subject'] = '%s - ¡Solicitud de exportación o borrado por RGPD!';
$_['text_export'] = 'Petición de exportación de datos';
$_['text_remove'] = 'Solicitud de eliminación de cuenta';
$_['text_gdpr'] = 'Una solicitud de GRPD desde esta dirección de correo electrónico. Para confirmar esta acción, por favor haz clic en el siguiente enlace:';
$_['text_ip'] = 'La dirección IP usada para hacer esta solicitud fue:';
$_['text_contact'] = 'Si no realizaste esta petición, por favor ponte en contacto con el dueño de la tienda aquí:';
$_['text_thanks'] = 'Gracias.';
$_['text_ignore'] = 'Si no generaste esta petición, por favor ignora este correo electrónico.';
$_['button_export'] = 'Confirmo la exportación de mis datos';
$_['button_remove'] = 'Confirmo la eliminación de mi cuenta';
