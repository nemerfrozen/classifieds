<?php

$_['text_subject'] = 'Se te ha enviado una tarjeta de regalo desde %s';
$_['text_greeting'] = 'Felicitaciones, has recibido una tarjeta de regalo de %s';
$_['text_from'] = 'Esta tarjeta de regalo ha sido enviada a ti por %s';
$_['text_message'] = 'Con un mensaje diciendo';
$_['text_redeem'] = 'Para canjear esta tarjeta de regalo, escribe su código el cual es <b>%s</b>, luego haz clic en el enlace siguiente y efectúa la compra del producto en el que desees usar esta tarjeta. Puedes ingresar el código en la página del carro de compras antes de que hagas clic en pagar.';
$_['text_footer'] = 'Por favor responde este correo electrónico si tienes alguna pregunta.';
