<?php

$_['heading_title'] = 'Usar puntos (%s disponibles)';
$_['text_reward'] = 'Puntos (%s)';
$_['text_order_id'] = 'ID de pedido: #%s';
$_['text_success'] = 'Éxito: ¡El descuento con tus puntos ha sido aplicado!';
$_['text_remove'] = 'Éxito: ¡Se ha quitado el descuento con tus puntos de recompensa!';
$_['entry_reward'] = 'Puntos a usar (máx. %s)';
$_['error_reward'] = 'Aviso: ¡Por favor ingresa la cantidad de puntos a utilizar!';
$_['error_points'] = 'Aviso: ¡No tienes %s puntos!';
$_['error_maximum'] = 'Aviso: ¡El número máximo de puntos que se pueden aplicar es de %s!';
$_['error_status'] = 'Aviso: ¡Los puntos de recompensa no están habilitados en esta tienda!';
