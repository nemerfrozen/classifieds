<?php

$_['heading_title'] = 'Transferencia bancaria';
$_['text_instruction'] = 'Instrucciones para transferencia bancaria';
$_['text_description'] = 'Por favor transfiera el monto total a la siguiente cuenta bancaria.';
$_['text_payment'] = 'Tu pedido no se enviará hasta que recibamos el pago.';
