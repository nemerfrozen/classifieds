<?php

$_['text_handling'] = 'Tasa de manejo';
