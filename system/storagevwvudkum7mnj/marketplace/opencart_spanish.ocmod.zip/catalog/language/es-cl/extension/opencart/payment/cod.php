<?php

$_['heading_title'] = 'Pago contra entrega';
$_['error_order_id'] = '¡Sin ID de pedido en la sesión!';
$_['error_payment_method'] = '¡El método de pago no es correcto!';
