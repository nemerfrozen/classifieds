<?php

$_['heading_title'] = 'Usar el código del cupón';
$_['text_coupon'] = 'Cupón (%s)';
$_['text_success'] = 'Éxito: ¡Se ha aplicado el cupón de descuento!';
$_['text_remove'] = 'Éxito: ¡Se ha removido tu cupón de descuento!';
$_['entry_coupon'] = 'Ingresa aquí tu cupón';
$_['error_coupon'] = 'Aviso: ¡El cupón podría no ser válido, expiró o alcanzó su límite de uso!';
$_['error_status'] = 'Aviso: ¡Los cupones no se habilitaron en esta tienda!';
