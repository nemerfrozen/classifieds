<?php

$_['heading_title'] = 'Cheque o giro postal';
$_['text_instruction'] = 'Instrucciones de pago para cheque y transferencia';
$_['text_payable'] = 'Hacer pagable a:';
$_['text_address'] = 'Enviar a:';
$_['text_payment'] = 'Tu pedido no se enviará hasta que recibamos el pago.';
