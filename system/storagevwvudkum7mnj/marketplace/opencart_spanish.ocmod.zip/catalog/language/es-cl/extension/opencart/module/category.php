<?php

$_['heading_title'] = 'Categorías';
