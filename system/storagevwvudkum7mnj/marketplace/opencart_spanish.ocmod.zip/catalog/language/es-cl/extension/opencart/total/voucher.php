<?php

$_['heading_title'] = 'Usar tarjeta de regalo';
$_['text_voucher'] = 'Tarjeta de regalo (%s)';
$_['text_success'] = 'Éxito: ¡Se ha aplicado el descuento de tu tarjeta de regalo!';
$_['text_remove'] = 'Éxito: ¡Se ha eliminado el descuento de tu tarjeta de regalo!';
$_['entry_voucher'] = 'Ingresa aquí el código de la tarjeta de regalo';
$_['error_voucher'] = 'Aviso: ¡La tarjeta de regalo no es válida o ya se utilizó su saldo!';
$_['error_status'] = 'Aviso: ¡Las tarjetas de regalo no están habilitadas en esta tienda!';
