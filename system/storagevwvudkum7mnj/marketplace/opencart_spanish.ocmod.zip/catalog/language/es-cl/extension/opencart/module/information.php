<?php

$_['heading_title'] = 'Información';
$_['text_contact'] = 'Contáctanos';
$_['text_sitemap'] = 'Mapa del sitio';
