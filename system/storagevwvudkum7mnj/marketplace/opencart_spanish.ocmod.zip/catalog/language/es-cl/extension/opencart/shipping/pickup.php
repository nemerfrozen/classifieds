<?php

$_['heading_title'] = 'Ir a buscar';
$_['text_description'] = 'Retirar en la tienda';
