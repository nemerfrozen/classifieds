<?php

$_['heading_title'] = 'Cuenta';
$_['text_register'] = 'Registro';
$_['text_login'] = 'Iniciar sesión';
$_['text_logout'] = 'Cerrar sesión';
$_['text_forgotten'] = 'Olvidé mi contraseña';
$_['text_account'] = 'Mi cuenta';
$_['text_edit'] = 'Editar cuenta';
$_['text_password'] = 'Contraseña';
$_['text_address'] = 'Libreta de direcciones';
$_['text_wishlist'] = 'Lista de deseos';
$_['text_order'] = 'Historial de pedidos';
$_['text_download'] = 'Descargas';
$_['text_reward'] = 'Puntos';
$_['text_return'] = 'Devoluciones';
$_['text_transaction'] = 'Transacciones';
$_['text_newsletter'] = 'Boletín informativo';
$_['text_subscription'] = 'Suscripciones';
