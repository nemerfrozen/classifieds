<?php

$_['text_captcha'] = 'Captcha';
$_['entry_captcha'] = 'Ingresa el código en la siguiente casilla';
$_['error_captcha'] = '¡El código de verificación no coincide con la imagen!';
