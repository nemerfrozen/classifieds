<?php

$_['heading_title'] = 'Los más vendidos';
