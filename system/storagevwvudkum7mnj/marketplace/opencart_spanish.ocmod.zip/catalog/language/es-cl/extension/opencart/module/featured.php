<?php

$_['heading_title'] = 'Destacados';
