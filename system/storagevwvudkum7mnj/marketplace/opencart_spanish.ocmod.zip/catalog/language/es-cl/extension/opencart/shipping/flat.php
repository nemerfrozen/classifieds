<?php

$_['heading_title'] = 'Tarifa plana';
$_['text_description'] = 'Tarifa plana de envío';
