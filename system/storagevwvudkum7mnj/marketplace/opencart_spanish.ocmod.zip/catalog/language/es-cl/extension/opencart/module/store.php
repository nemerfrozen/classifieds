<?php

$_['heading_title'] = 'Elige una tienda';
$_['text_default'] = 'Predeterminado';
$_['text_store'] = 'Por favor elige la tienda que deseas visitar.';
