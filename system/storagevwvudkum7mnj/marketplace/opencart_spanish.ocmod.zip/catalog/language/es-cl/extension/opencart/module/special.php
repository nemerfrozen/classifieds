<?php

$_['heading_title'] = 'Ofertas especiales';
