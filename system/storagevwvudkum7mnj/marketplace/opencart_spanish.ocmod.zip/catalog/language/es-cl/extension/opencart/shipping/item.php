<?php

$_['heading_title'] = 'Por artículo';
$_['text_description'] = 'Tasa de envío por artículo';
