<?php

$_['heading_title'] = 'Lo último';
