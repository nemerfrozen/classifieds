<?php

$_['text_credit'] = 'Crédito de la tienda';
$_['text_order_id'] = 'ID de pedido: #%s';
