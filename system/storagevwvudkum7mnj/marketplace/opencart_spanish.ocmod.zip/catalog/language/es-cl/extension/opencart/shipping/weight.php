<?php

$_['heading_title'] = 'Envío basado en peso';
$_['text_weight'] = 'Peso:';
