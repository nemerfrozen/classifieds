<?php

$_['text_error'] = '¡No se encuentra la página de información!';
