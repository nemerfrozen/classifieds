<?php

$_['heading_title'] = 'RGPD exitoso';
$_['text_account'] = 'Cuenta';
$_['text_export'] = 'Se ha recibido una petición para exportar los datos de tu cuenta.';
$_['text_remove'] = 'Las solicitudes de eliminación de cuenta por RGPD se procesarán luego de <strong>%s días</strong>, así se podrá procesar cualquier reversa de pago, reembolso o detección de fraude.';
