<?php
$_['heading_title'] = 'Spanish Language';
$_['text_extension'] = 'Extensions';
$_['text_success'] = 'Success: You have modified Spanish language!';
$_['text_edit'] = 'Edit Spanish Language';
$_['entry_status'] = 'Status';
$_['error_permission'] = 'Warning: You do not have permission to modify Spanish language!';