<?php

$_['heading_title'] = 'Empresa emergente';
$_['text_success'] = 'Éxito: ¡Has modificado el módulo de empresa emergente!';
$_['text_list'] = 'Lista de empresas emergentes';
$_['column_code'] = 'Código de empresa emergente';
$_['column_sort_order'] = 'Orden';
$_['column_action'] = 'Acción';
$_['error_permission'] = 'Aviso: ¡No tienes permiso para modificar el módulo de empresa emergente!';
