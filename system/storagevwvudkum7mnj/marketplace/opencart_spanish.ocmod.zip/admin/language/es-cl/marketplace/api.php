<?php

$_['heading_title'] = 'API de mercado de OpenCart';
$_['text_success'] = 'Éxito: ¡Has modificado tu información de la API!';
$_['text_signup'] = 'Por favor ingresa la información de la API de OpenCart, la cual puedes obtener <a href="https://www.opencart.com/index.php?route=account/store" target="_blank" class="alert-link">aquí</a>.';
$_['entry_username'] = 'Nombre de usuario';
$_['entry_secret'] = 'Secreto';
$_['error_permission'] = 'Aviso: ¡No tienes permiso para modificar la API del mercado!';
$_['error_username'] = '¡Se requiere el nombre de usuario!';
$_['error_secret'] = '¡Se requiere el secreto!';
