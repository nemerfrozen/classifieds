<?php

$_['heading_title'] = 'Extensiones';
$_['text_success'] = 'Éxito: ¡Has modificado las extensiones!';
$_['text_list'] = 'Lista de extensiones';
$_['text_type'] = 'Elige el tipo de extensión';
$_['text_filter'] = 'Filtrar';
