<?php

$_['heading_title'] = 'Eventos';
$_['text_success'] = 'Éxito: ¡Has modificado los eventos!';
$_['text_list'] = 'Lista de eventos';
$_['text_event'] = 'Los eventos son utilizados por las extensiones para pasar por alto la funcionalidad predeterminada de tu tienda. Si tienes problemas, puedes desactivar o activar los eventos aquí.';
$_['text_info'] = 'Información del evento';
$_['column_code'] = 'Código de evento';
$_['column_sort_order'] = 'Orden';
$_['column_action'] = 'Acción';
$_['entry_description'] = 'Descripción';
$_['entry_trigger'] = 'Disparador';
$_['entry_action'] = 'Acción';
$_['error_permission'] = 'Aviso: ¡No tienes permiso para modificar los eventos!';
