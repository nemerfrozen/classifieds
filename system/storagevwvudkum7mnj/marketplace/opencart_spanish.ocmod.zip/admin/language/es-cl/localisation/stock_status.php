<?php

$_['heading_title'] = 'Estados de existencias';
$_['text_success'] = 'Éxito: ¡Has modificado los estados de las existencias!';
$_['text_list'] = 'Lista de estados de existencias';
$_['text_add'] = 'Agregar estado de existencias';
$_['text_edit'] = 'Editar estado de existencias';
$_['column_name'] = 'Nombre de estado de existencias';
$_['column_action'] = 'Acción';
$_['entry_name'] = 'Nombre de estado de existencias';
$_['error_permission'] = 'Aviso: ¡No tienes permiso para modificar los estados de las existencias!';
$_['error_name'] = '¡El estado de existencia en bodega debe tener entre 3 y 32 caracteres!';
$_['error_product'] = 'Aviso: ¡No se puede eliminar este estado de existencias debido a que se encuentra asignado a %s productos!';
