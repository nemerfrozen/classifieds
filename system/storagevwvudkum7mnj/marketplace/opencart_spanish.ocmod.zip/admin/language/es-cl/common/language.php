<?php

$_['error_language'] = 'Aviso: ¡No se pudo encontrar el idioma!';
