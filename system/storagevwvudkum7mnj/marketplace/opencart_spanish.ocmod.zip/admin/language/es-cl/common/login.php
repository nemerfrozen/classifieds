<?php

$_['heading_title'] = 'Administración';
$_['text_heading'] = 'Administración';
$_['text_login'] = 'Por favor ingresa tus datos para iniciar sesión';
$_['text_forgotten'] = 'Olvidé mi contraseña';
$_['entry_username'] = 'Nombre de usuario';
$_['entry_password'] = 'Contraseña';
$_['button_login'] = 'Iniciar sesión';
$_['error_login'] = 'No se encuentran coincidencias para esta mezcla de nombre de usuario y contraseña.';
$_['error_token'] = 'El token de sesión no es válido. Por favor inicia sesión otra vez.';
