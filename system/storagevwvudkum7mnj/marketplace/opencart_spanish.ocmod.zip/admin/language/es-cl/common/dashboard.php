<?php

$_['heading_title'] = 'Panel de control';
