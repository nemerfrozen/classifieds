<?php

$_['heading_title'] = 'OpenCart';
$_['text_notification'] = 'Notificaciones';
$_['text_notification_all'] = 'Mostrar todo';
$_['text_notification_none'] = 'No hay notificaciones';
$_['text_profile'] = 'Tu perfil';
$_['text_store'] = 'Tiendas';
$_['text_help'] = 'Ayuda';
$_['text_homepage'] = 'Página de inicio de OpenCart';
$_['text_support'] = 'Foros de soporte';
$_['text_documentation'] = 'Documentación';
$_['text_logout'] = 'Cerrar sesión';
