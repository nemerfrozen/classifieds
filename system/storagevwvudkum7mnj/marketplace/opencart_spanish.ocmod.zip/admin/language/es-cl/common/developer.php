<?php

$_['heading_title'] = 'Preferencias de desarrollador';
$_['text_success'] = 'Éxito: ¡Has modificado las preferencias de desarrollador!';
$_['text_theme'] = 'Tema';
$_['text_sass'] = 'SASS';
$_['text_cache'] = 'Éxito: ¡Has limpiado el caché de %s!';
$_['column_component'] = 'Componente';
$_['column_action'] = 'Acción';
$_['entry_theme'] = 'Tema';
$_['entry_sass'] = 'SASS';
$_['entry_cache'] = 'Caché';
$_['button_on'] = 'Activo';
$_['button_off'] = 'Inactivo';
$_['error_permission'] = 'Aviso: ¡No tienes permiso para modificar las preferencias de desarrollador!';
