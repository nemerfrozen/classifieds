<?php

$_['text_footer'] = '<a href="http://www.opencart.com">OpenCart</a> &copy; 2009-2024 Todos los derechos reservados.';
$_['text_version'] = 'Versión %s<br /><small>Traducido por <a href="https://burbuja.cl/">Burbuja</a></small>';
