<?php
$_['heading_title'] = 'Idioma español';
$_['text_extension'] = 'Extensiones';
$_['text_success'] = 'Éxito: ¡Has modificado el idioma español!';
$_['text_edit'] = 'Editar idioma español';
$_['entry_status'] = 'Estado';
$_['error_permission'] = 'Aviso: ¡No tienes permiso para modificar el idioma español!';