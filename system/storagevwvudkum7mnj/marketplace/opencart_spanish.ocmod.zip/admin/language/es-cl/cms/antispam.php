<?php

$_['heading_title'] = 'Antispam';
$_['text_success'] = 'Éxito: ¡Has modificado el antispam!';
$_['text_list'] = 'Lista antispam';
$_['text_add'] = 'Agregar antispam';
$_['text_edit'] = 'Editar antispam';
$_['column_keyword'] = 'Palabra clave';
$_['column_action'] = 'Acción';
$_['entry_keyword'] = 'Palabra clave';
$_['error_warning'] = 'Aviso: ¡Por favor revise cuidadosamente los errores del formulario!';
$_['error_permission'] = 'Aviso: ¡No tienes permiso para modificar el módulo de antispam!';
$_['error_keyword'] = '¡La palabra clave debe tener entre 1 y 64 caracteres!';
$_['error_keyword_exists'] = '¡La palabra clave debe ser única!';
