<?php

$_['text_subject'] = '%s - ¡Tu cuenta de afiliado ha sido rechazada!';
$_['text_welcome'] = '¡Bienvenido y gracias por registrarse en %s!';
$_['text_denied'] = 'Lamentablemente se rechazó tu petición. Para más información puedes ponerte en contacto con el dueño de la tienda aquí:';
$_['text_thanks'] = 'Gracias.';
