<?php

$_['text_subject'] = '%s - Crédito de afiliado';
$_['text_received'] = '¡Has recibido %s créditos!';
$_['text_total'] = 'Tu monto total del crédito es ahora de %s.';
$_['text_credit'] = 'El crédito de tu cuenta se puede deducir de tu próxima compra.';
