<?php

$_['text_subject'] = '%s - Puntos';
$_['text_received'] = '¡Has recibido %s puntos!';
$_['text_total'] = 'El total actual de puntos es de %s.';
