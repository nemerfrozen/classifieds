<?php

$_['text_subject'] = '%s - ¡la solicitud de RGPD ha sido procesada!';
$_['text_request'] = 'Solicitud de eliminación de cuenta';
$_['text_hello'] = 'Hola <strong>%s</strong>,';
$_['text_user'] = 'Usuario';
$_['text_delete'] = 'Tu solicitud de eliminación de datos por RGPD, se ha completado.';
$_['text_contact'] = 'Para mayor información, puedes ponerte en contacto con el dueño de la tienda aquí:';
$_['text_thanks'] = 'Gracias.';
$_['button_contact'] = 'Contáctanos';
