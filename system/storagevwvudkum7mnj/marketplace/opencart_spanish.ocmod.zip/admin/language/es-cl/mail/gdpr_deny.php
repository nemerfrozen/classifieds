<?php

$_['text_subject'] = '%s - ¡solicitud de RGPD rechazada!';
$_['text_export'] = 'Solicitud de exportación de datos de la cuenta';
$_['text_remove'] = 'Solicitud de eliminación de cuenta';
$_['text_hello'] = 'Hola <strong>%s</strong>,';
$_['text_user'] = 'Usuario';
$_['text_contact'] = 'Lamentablemente, tu solicitud se ha rechazado. Para más información, puedes ponerte en contacto con la tienda aquí:';
$_['text_thanks'] = 'Gracias.';
$_['button_contact'] = 'Contáctanos';
