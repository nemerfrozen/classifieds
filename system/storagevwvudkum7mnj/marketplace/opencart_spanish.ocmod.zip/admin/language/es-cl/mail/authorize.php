<?php

$_['text_subject'] = 'Seguridad';
$_['text_code'] = 'Debes ingresar el código de seguridad en la verificación de seguridad de administrador.';
$_['text_ip'] = 'IP:';
$_['text_regards'] = 'Saludos cordiales';
