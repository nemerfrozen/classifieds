<?php

$_['text_success'] = 'Éxito: ¡Has modificado las tarjetas de regalo!';
$_['text_subject'] = 'Se te ha enviado una tarjeta de regalo desde %s';
$_['text_greeting'] = 'Felicitaciones, has recibido una tarjeta de regalo de %s';
$_['text_from'] = 'Esta tarjeta de regalo ha sido enviada a ti por %s';
$_['text_message'] = 'Con un mensaje diciendo';
$_['text_redeem'] = 'En primer lugar, para canjear esta tarjeta de regalo, escribe el código de canje el cual es <b>%s</b>. Luego, haz clic en el siguiente enlace y compra el producto que desees para utilizar esta tarjeta de regalo. Finalmente, puedes ingresar el código de la tarjeta de regalo en la página del <b>carro de compra</b> antes de que hagas clic en <b>pagar</b>.';
$_['text_footer'] = 'Por favor responde a este mensaje si tienes alguna pregunta.';
$_['text_sent'] = 'Aviso: ¡El correo electrónico con la tarjeta de regalo ha sido enviado!';
