<?php

$_['text_subject'] = '%s - Suscripción';
$_['text_subscription_id'] = 'ID de suscripción';
$_['text_date_added'] = 'Fecha de suscripción:';
$_['text_subscription_status'] = 'Se ha agregado tu suscripción al siguiente estado:';
$_['text_comment'] = 'Los comentarios para tu suscripción son:';
$_['text_payment_method'] = 'Método de pago';
$_['text_payment_code'] = 'Código de pago';
$_['text_footer'] = 'Por favor responde a este mensaje si tienes alguna pregunta.';
