<?php

$_['text_subject'] = '%s - Actualización de la devolución %s';
$_['text_return_id'] = 'ID de devolución:';
$_['text_date_added'] = 'Fecha de devolución:';
$_['text_return_status'] = 'Tu devolución ha sido actualizada al siguiente estado:';
$_['text_comment'] = 'Los comentarios para tu devolución son:';
$_['text_footer'] = 'Por favor responde a este mensaje si tienes alguna pregunta.';
