<?php

$_['text_subject'] = '%s - ¡Tu cuenta ha sido activada!';
$_['text_welcome'] = '¡Bienvenido y gracias por registrarse en %s!';
$_['text_login'] = 'Tu cuenta se ha creado y puedes iniciar sesión usando tu dirección de correo electrónico y contraseña visitando nuestro sitio web o en la siguiente URL:';
$_['text_service'] = 'Luego de iniciar sesión, podrás acceder a otros servicios incluyendo comentar pedidos anteriores, imprimir recibos y editar información de tu cuenta.';
$_['text_thanks'] = 'Gracias.';
$_['button_login'] = 'Iniciar sesión';
