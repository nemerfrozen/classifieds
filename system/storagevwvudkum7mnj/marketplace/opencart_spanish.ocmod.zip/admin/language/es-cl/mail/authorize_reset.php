<?php

$_['text_subject'] = 'Intentos para restablecer el código de seguridad';
$_['text_reset'] = 'Alguien ingresó mal el código de seguridad por más de 3 veces.';
$_['text_link'] = 'Haz clic en el siguiente enlace para restablecer la seguridad de la cuenta:';
$_['text_ip'] = 'IP:';
$_['text_regards'] = 'Saludos cordiales';
