<?php

$_['text_subject'] = '%s - ¡solicitud de RGPD aprobada!';
$_['text_request'] = 'Solicitud de eliminación de cuenta';
$_['text_hello'] = 'Hola <strong>%s</strong>,';
$_['text_user'] = 'Usuario';
$_['text_gdpr'] = 'Tu solicitud de eliminación de datos por RGPD se ha aprobado y se eliminarán en <strong>%s días</strong>.';
$_['text_q'] = 'P. ¿Por qué no eliminamos tus datos inmediatamente?';
$_['text_a'] = 'Las solicitudes de eliminación de cuenta se procesarán luego de <strong>%s días</strong>, así se podrá procesar cualquier reembolso, reversa de pago o detección de fraude.';
$_['text_delete'] = 'Recibirás un mensaje por correo electrónico informando que tu cuenta se ha eliminado.';
$_['text_thanks'] = 'Gracias.';
