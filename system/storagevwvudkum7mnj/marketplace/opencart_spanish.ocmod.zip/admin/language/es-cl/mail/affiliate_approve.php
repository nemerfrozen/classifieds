<?php

$_['text_subject'] = '%s - ¡Se ha activado tu cuenta de afiliado!';
$_['text_welcome'] = '¡Bienvenido y gracias por registrarse en %s!';
$_['text_login'] = 'Se ha aprobado tu cuenta y puedes iniciar sesión utilizando tu dirección de correo electrónico y contraseña, visitando nuestro sitio web en la siguiente URL:';
$_['text_service'] = 'Una vez iniciada la sesión, podrás generar códigos de seguimiento, hacer seguimiento a pagos de comisión y editar la información de tu cuenta.';
$_['text_thanks'] = 'Gracias.';
