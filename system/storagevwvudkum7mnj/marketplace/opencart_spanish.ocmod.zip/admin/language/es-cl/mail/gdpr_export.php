<?php

$_['text_subject'] = '%s - ¡Se completó la solicitud de exportación por RGPD!';
$_['text_request'] = 'Exportar datos personales';
$_['text_hello'] = 'Hola <strong>%s</strong>,';
$_['text_user'] = 'Usuario';
$_['text_gdpr'] = 'Se ha completado tu solicitud de datos por RGPD. Encontrarás a continuación tus datos de RGPD.';
$_['text_account'] = 'Cuenta';
$_['text_customer'] = 'Información personal';
$_['text_address'] = 'Dirección';
$_['text_addresses'] = 'Direcciones';
$_['text_name'] = 'Nombre de cliente';
$_['text_recipient'] = 'Destinatario';
$_['text_email'] = 'Correo electrónico';
$_['text_telephone'] = 'Teléfono';
$_['text_company'] = 'Empresa';
$_['text_address_1'] = 'Dirección 1';
$_['text_address_2'] = 'Dirección 2';
$_['text_postcode'] = 'Código postal';
$_['text_city'] = 'Ciudad';
$_['text_country'] = 'País';
$_['text_zone'] = 'Región o estado';
$_['text_history'] = 'Historial de inicios de sesión';
$_['text_ip'] = 'IP';
$_['text_date_added'] = 'Fecha de alta';
$_['text_thanks'] = 'Gracias.';
