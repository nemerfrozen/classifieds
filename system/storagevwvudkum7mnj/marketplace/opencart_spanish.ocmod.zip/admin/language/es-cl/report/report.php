<?php

$_['heading_title'] = 'Informes';
$_['text_success'] = 'Éxito: ¡Has modificado los informes!';
$_['text_type'] = 'Elige el tipo de informe';
$_['text_filter'] = 'Filtrar';
