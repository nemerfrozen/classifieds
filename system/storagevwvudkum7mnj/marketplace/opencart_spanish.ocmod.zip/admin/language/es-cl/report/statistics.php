<?php

$_['heading_title'] = 'Estadísticas';
$_['text_success'] = 'Éxito: ¡Has modificado el módulo de estadísticas!';
$_['text_list'] = 'Lista de estadísticas';
$_['text_order_sale'] = 'Ventas de pedidos';
$_['text_order_processing'] = 'Pedidos en proceso';
$_['text_order_complete'] = 'Pedidos completos';
$_['text_order_other'] = 'Otros pedidos';
$_['text_returns'] = 'Devoluciones';
$_['text_customer'] = 'Clientes esperando aprobación';
$_['text_affiliate'] = 'Afiliados esperando aprobación';
$_['text_product'] = 'Productos sin existencias';
$_['text_review'] = 'Opiniones pendientes';
$_['column_name'] = 'Nombre de estadística';
$_['column_value'] = 'Valor';
$_['column_action'] = 'Acción';
$_['error_permission'] = 'Aviso: ¡No tienes permiso para modificar las estadísticas!';
