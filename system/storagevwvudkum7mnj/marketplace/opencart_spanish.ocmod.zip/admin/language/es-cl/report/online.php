<?php

$_['heading_title'] = 'Usuarios conectados';
$_['text_extension'] = 'Extensiones';
$_['text_success'] = 'Éxito: ¡Has modificado el informe de clientes conectados!';
$_['text_list'] = 'Lista de clientes conectados';
$_['text_filter'] = 'Filtrar';
$_['text_guest'] = 'Invitado';
$_['column_ip'] = 'IP';
$_['column_customer'] = 'Cliente';
$_['column_url'] = 'Última página visitada';
$_['column_referer'] = 'Referido';
$_['column_date_added'] = 'Último clic';
$_['column_action'] = 'Acción';
$_['entry_ip'] = 'IP';
$_['entry_customer'] = 'Cliente';
$_['error_permission'] = 'Éxito: ¡No tienes permiso para modificar el informe de clientes conectados!';
