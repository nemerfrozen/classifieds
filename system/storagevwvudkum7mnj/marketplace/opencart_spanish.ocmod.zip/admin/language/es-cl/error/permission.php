<?php

$_['heading_title'] = '¡Permiso rechazado!';
$_['text_permission'] = 'No tienes permiso para acceder a esta página, por favor consúltalo con el administrador del sistema.';
