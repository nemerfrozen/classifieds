<?php

$_['heading_title'] = '¡No se encuentra la página!';
$_['text_not_found'] = '¡La página que buscas no se pudo encontrar! Por favor ponte en contacto con tu administrador si este inconveniente persiste.';
