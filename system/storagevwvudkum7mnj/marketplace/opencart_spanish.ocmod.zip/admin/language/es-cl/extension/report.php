<?php

$_['heading_title'] = 'Informes';
$_['text_success'] = 'Éxito: ¡Has modificado los informes!';
$_['text_list'] = 'Lista de informes';
$_['column_name'] = 'Nombre de informe';
$_['column_status'] = 'Estado';
$_['column_sort_order'] = 'Orden';
$_['column_action'] = 'Acción';
$_['error_permission'] = 'Aviso: ¡No tienes permiso para modificar los informes!';
$_['error_extension'] = 'Aviso: ¡La extensión no existe!';
