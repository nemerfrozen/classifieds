<?php

$_['heading_title'] = 'Crédito de la tienda';
$_['text_extension'] = 'Extensiones';
$_['text_success'] = 'Éxito: ¡Has modificado el crédito total de la tienda!';
$_['text_edit'] = 'Editar total de crédito de tienda';
$_['entry_status'] = 'Estado';
$_['entry_sort_order'] = 'Orden';
$_['error_permission'] = 'Aviso: ¡No tienes permiso para modificar el total de crédito de la tienda!';
