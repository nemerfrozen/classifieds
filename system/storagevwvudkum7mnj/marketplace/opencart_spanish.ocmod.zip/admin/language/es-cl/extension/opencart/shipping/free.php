<?php

$_['heading_title'] = 'Envío gratis';
$_['text_extension'] = 'Extensiones';
$_['text_success'] = 'Éxito: ¡Has modificado el envío gratis!';
$_['text_edit'] = 'Editar envío gratis';
$_['entry_total'] = 'Subtotal';
$_['entry_geo_zone'] = 'Zona geográfica';
$_['entry_status'] = 'Estado';
$_['entry_sort_order'] = 'Orden';
$_['help_total'] = 'El monto de subtotal necesario antes de que el módulo de envío gratis esté disponible.';
$_['error_permission'] = 'Aviso: ¡No tienes permiso para modificar el módulo de envío gratis!';
