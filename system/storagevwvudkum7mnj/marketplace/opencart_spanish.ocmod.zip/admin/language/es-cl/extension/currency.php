<?php

$_['heading_title'] = 'Tasas de divisas';
$_['text_success'] = 'Éxito: ¡Has modificado las tasas de las divisas!';
$_['text_list'] = 'Lista de tasas de divisa';
$_['column_name'] = 'Nombre de tasa de divisa';
$_['column_status'] = 'Estado';
$_['column_action'] = 'Acción';
$_['error_permission'] = 'Aviso: ¡No tienes permiso para modificar las tasas de divisas!';
$_['error_extension'] = 'Aviso: ¡La extensión no existe!';
