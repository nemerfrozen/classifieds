<?php

$_['heading_title'] = 'Transferencia bancaria';
$_['text_extension'] = 'Extensiones';
$_['text_success'] = 'Éxito: ¡Has modificado los detalles de transferencia bancaria!';
$_['text_edit'] = 'Editar transferencia bancaria';
$_['entry_bank'] = 'Instrucciones para transferencia bancaria';
$_['entry_order_status'] = 'Estado del pedido';
$_['entry_geo_zone'] = 'Zona geográfica';
$_['entry_status'] = 'Estado';
$_['entry_sort_order'] = 'Orden';
$_['error_permission'] = 'Aviso: ¡No tienes permiso para modificar el pago por transferencia bancaria!';
$_['error_bank'] = '¡Se requieren las instrucciones de transferencia bancaria!';
