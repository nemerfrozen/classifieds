<?php

$_['heading_title'] = 'Tarjeta de regalo';
$_['text_extension'] = 'Extensiones';
$_['text_success'] = 'Éxito: ¡Has modificado el total de la tarjeta de regalo!';
$_['text_edit'] = 'Editar total de tarjeta de regalo';
$_['entry_status'] = 'Estado';
$_['entry_sort_order'] = 'Orden';
$_['error_permission'] = 'Aviso: ¡No tienes permiso para modificar el total de la tarjeta de regalo!';
