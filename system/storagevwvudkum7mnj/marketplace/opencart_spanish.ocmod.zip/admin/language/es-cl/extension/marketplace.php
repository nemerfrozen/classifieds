<?php

$_['heading_title'] = 'Mercados';
$_['text_success'] = 'Éxito: ¡Has modificado el módulo de mercados!';
$_['text_list'] = 'Lista de mercados';
$_['column_name'] = 'Nombre de mercado';
$_['column_status'] = 'Estado';
$_['column_action'] = 'Acción';
$_['error_permission'] = 'Aviso: ¡No tienes permiso para modificar el módulo de mercados!';
$_['error_extension'] = 'Aviso: ¡La extensión no existe!';
