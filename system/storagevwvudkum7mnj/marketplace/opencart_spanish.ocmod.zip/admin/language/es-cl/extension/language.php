<?php

$_['heading_title'] = 'Idiomas';
$_['text_success'] = 'Éxito: ¡Has modificado los idiomas!';
$_['text_list'] = 'Lista de idiomas';
$_['column_name'] = 'Nombre de idioma';
$_['column_status'] = 'Estado';
$_['column_action'] = 'Acción';
$_['error_permission'] = 'Aviso: ¡No tienes permiso para modificar los idiomas!';
$_['error_extension'] = 'Aviso: ¡La extensión no existe!';
