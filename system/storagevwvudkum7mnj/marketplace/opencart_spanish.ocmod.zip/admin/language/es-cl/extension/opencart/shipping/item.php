<?php

$_['heading_title'] = 'Por artículo';
$_['text_extension'] = 'Extensiones';
$_['text_success'] = 'Éxito: ¡Has modificado las tasas de envío por artículo!';
$_['text_edit'] = 'Editar envío por artículo';
$_['entry_cost'] = 'Costo';
$_['entry_tax_class'] = 'Tipo de impuesto';
$_['entry_geo_zone'] = 'Zona geográfica';
$_['entry_status'] = 'Estado';
$_['entry_sort_order'] = 'Orden';
$_['error_permission'] = 'Aviso: ¡No tienes permiso para modificar las tarifas de envío por artículo!';
