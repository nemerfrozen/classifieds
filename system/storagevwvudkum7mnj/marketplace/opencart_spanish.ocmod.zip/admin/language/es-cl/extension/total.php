<?php

$_['heading_title'] = 'Totales del pedido';
$_['text_success'] = 'Éxito: ¡Has modificado los totales!';
$_['column_name'] = 'Totales del pedido';
$_['column_status'] = 'Estado';
$_['column_sort_order'] = 'Orden';
$_['column_action'] = 'Acción';
$_['error_permission'] = 'Aviso: ¡No tienes permiso para modificar los totales!';
$_['error_extension'] = 'Aviso: ¡La extensión no existe!';
