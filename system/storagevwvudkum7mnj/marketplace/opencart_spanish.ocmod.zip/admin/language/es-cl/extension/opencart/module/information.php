<?php

$_['heading_title'] = 'Información';
$_['text_extension'] = 'Extensiones';
$_['text_success'] = 'Éxito: ¡Has modificado el módulo de información!';
$_['text_edit'] = 'Editar módulo de información';
$_['entry_status'] = 'Estado';
$_['error_permission'] = 'Aviso: ¡No tienes permiso para modificar el módulo de información!';
