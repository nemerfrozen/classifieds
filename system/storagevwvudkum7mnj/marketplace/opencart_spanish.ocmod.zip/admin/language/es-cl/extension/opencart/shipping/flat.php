<?php

$_['heading_title'] = 'Tarifa plana';
$_['text_extension'] = 'Extensiones';
$_['text_success'] = 'Éxito: ¡Has modificado el envío de tarifa plana!';
$_['text_edit'] = 'Editar tarifa plana de envío';
$_['entry_cost'] = 'Costo';
$_['entry_tax_class'] = 'Tipo de impuesto';
$_['entry_geo_zone'] = 'Zona geográfica';
$_['entry_status'] = 'Estado';
$_['entry_sort_order'] = 'Orden';
$_['error_permission'] = 'Aviso: ¡No tienes permiso para modificar la tarifa plana de envío!';
