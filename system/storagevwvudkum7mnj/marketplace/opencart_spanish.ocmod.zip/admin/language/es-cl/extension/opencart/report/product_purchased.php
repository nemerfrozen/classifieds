<?php

$_['heading_title'] = 'Informe de productos comprados';
$_['text_extension'] = 'Extensiones';
$_['text_edit'] = 'Editar informe de productos comprados';
$_['text_success'] = 'Éxito: ¡Has modificado el informe de productos comprados!';
$_['text_filter'] = 'Filtrar';
$_['text_all_status'] = 'Todos los estados';
$_['column_date_start'] = 'Fecha de inicio';
$_['column_date_end'] = 'Fecha de fin';
$_['column_name'] = 'Nombre de producto';
$_['column_model'] = 'Modelo';
$_['column_quantity'] = 'Cantidad';
$_['column_total'] = 'Total';
$_['entry_date_start'] = 'Fecha de inicio';
$_['entry_date_end'] = 'Fecha de fin';
$_['entry_order_status'] = 'Estado del pedido';
$_['entry_status'] = 'Estado';
$_['entry_sort_order'] = 'Orden';
$_['error_permission'] = 'Aviso: ¡No tienes permiso para modificar el informe de productos comprados!';
