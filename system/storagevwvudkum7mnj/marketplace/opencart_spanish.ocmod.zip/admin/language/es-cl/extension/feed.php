<?php

$_['heading_title'] = 'Fuentes';
$_['text_success'] = 'Éxito: ¡Has modificado las fuentes!';
$_['text_list'] = 'Lista de fuentes';
$_['column_name'] = 'Nombre de fuente de productos';
$_['column_status'] = 'Estado';
$_['column_action'] = 'Acción';
$_['error_permission'] = 'Aviso: ¡No tienes permiso para modificar las fuentes!';
$_['error_extension'] = 'Aviso: ¡La extensión no existe!';
