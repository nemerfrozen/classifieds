<?php

$_['heading_title'] = 'Tienda';
$_['text_extension'] = 'Extensiones';
$_['text_success'] = 'Éxito: ¡Has modificado el módulo de la tienda!';
$_['text_edit'] = 'Editar módulo de la tienda';
$_['entry_admin'] = 'Solo usuarios administradores';
$_['entry_status'] = 'Estado';
$_['error_permission'] = 'Aviso: ¡No tienes permiso para modificar el módulo de la tienda!';
