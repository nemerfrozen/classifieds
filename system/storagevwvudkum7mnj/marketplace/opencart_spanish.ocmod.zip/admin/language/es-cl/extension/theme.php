<?php

$_['heading_title'] = 'Temas';
$_['text_success'] = 'Éxito: ¡Has modificado los temas!';
$_['column_name'] = 'Nombre de tema';
$_['column_status'] = 'Estado';
$_['column_action'] = 'Acción';
$_['error_permission'] = 'Aviso: ¡No tienes permiso para modificar los temas!';
$_['error_extension'] = 'Aviso: ¡La extensión no existe!';
