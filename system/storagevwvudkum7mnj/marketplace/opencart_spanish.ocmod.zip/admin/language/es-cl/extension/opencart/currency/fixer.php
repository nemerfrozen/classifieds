<?php

$_['heading_title'] = 'Fixer';
$_['text_extension'] = 'Extensiones';
$_['text_success'] = 'Éxito: ¡Has modificado las tasas de divisas de Fixer!';
$_['text_edit'] = 'Editar Fixer';
$_['text_signup'] = 'Fixer.io es un servicio de conversión de divisas <a href="https://fixer.io/" target="_blank" class="alert-link">signup here</a>.';
$_['entry_api'] = 'Clave de acceso a la API';
$_['entry_status'] = 'Estado';
$_['error_permission'] = 'Aviso: ¡No tienes permiso para modificar las tasas de divisas de Fixer!';
$_['error_api'] = '¡Se requiere la clave de la API de acceso!';
