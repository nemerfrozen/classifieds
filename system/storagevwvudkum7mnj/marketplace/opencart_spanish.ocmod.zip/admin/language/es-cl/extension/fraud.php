<?php

$_['heading_title'] = 'Antifraude';
$_['text_success'] = 'Éxito: ¡Has modificado el antifraude!';
$_['text_list'] = 'Lista de antifraude';
$_['column_name'] = 'Nombre de anti-fraude';
$_['column_status'] = 'Estado';
$_['column_action'] = 'Acción';
$_['error_permission'] = 'Aviso: ¡No tienes permiso para modificar el módulo antifraude!';
$_['error_extension'] = 'Aviso: ¡La extensión no existe!';
