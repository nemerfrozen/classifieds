<?php

$_['heading_title'] = 'Pago contra entrega';
$_['text_extension'] = 'Extensiones';
$_['text_success'] = 'Éxito: ¡Has modificado el módulo de pago contra entrega!';
$_['text_edit'] = 'Editar pago contra entrega';
$_['entry_order_status'] = 'Estado del pedido';
$_['entry_geo_zone'] = 'Zona geográfica';
$_['entry_status'] = 'Estado';
$_['entry_sort_order'] = 'Orden';
$_['error_permission'] = 'Aviso: ¡No tienes permiso para modificar pago contra entrega!';
