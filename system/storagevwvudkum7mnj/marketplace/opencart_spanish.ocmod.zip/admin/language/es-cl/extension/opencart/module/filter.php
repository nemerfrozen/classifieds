<?php

$_['heading_title'] = 'Filtrar';
$_['text_extension'] = 'Extensiones';
$_['text_success'] = 'Éxito: ¡Has modificado el módulo de filtro!';
$_['text_edit'] = 'Editar módulo de filtro';
$_['entry_status'] = 'Estado';
$_['error_permission'] = 'Aviso: ¡No tienes permiso para modificar el módulo de filtro!';
