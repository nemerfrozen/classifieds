<?php

$_['heading_title'] = 'Cheque o giro postal';
$_['text_extension'] = 'Extensiones';
$_['text_success'] = 'Éxito: ¡Has modificado los detalles de la cuenta de cheque y orden de pago!';
$_['text_edit'] = 'Editar cheque o giro postal';
$_['entry_payable'] = 'Pagable a';
$_['entry_order_status'] = 'Estado del pedido';
$_['entry_geo_zone'] = 'Zona geográfica';
$_['entry_status'] = 'Estado';
$_['entry_sort_order'] = 'Orden';
$_['error_permission'] = 'Aviso: ¡No tienes permiso para modificar el pago por cheque o giro postal!';
$_['error_payable'] = '¡Se requiere el receptor del pago!';
