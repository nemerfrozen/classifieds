<?php

$_['heading_title'] = 'Clientes totales';
$_['text_extension'] = 'Extensiones';
$_['text_success'] = 'Éxito: ¡Has modificado el panel de control de cliente!';
$_['text_edit'] = 'Editar panel de control de cliente';
$_['text_view'] = 'Ver más...';
$_['entry_status'] = 'Estado';
$_['entry_sort_order'] = 'Orden';
$_['entry_width'] = 'Ancho';
$_['error_permission'] = 'Aviso: ¡No tienes permiso para modificar el panel de control de cliente!';
