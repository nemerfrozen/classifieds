<?php

$_['heading_title'] = 'Envío';
$_['text_extension'] = 'Extensiones';
$_['text_success'] = 'Éxito: ¡Has modificado el total del despacho!';
$_['text_edit'] = 'Editar total de despacho';
$_['entry_estimator'] = 'Cotizador de costo de envío';
$_['entry_status'] = 'Estado';
$_['entry_sort_order'] = 'Orden';
$_['error_permission'] = 'Aviso: ¡No tienes permiso para modificar el total del envío!';
