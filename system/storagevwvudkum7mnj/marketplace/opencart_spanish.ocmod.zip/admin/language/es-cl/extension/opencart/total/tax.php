<?php

$_['heading_title'] = 'Impuestos';
$_['text_extension'] = 'Extensiones';
$_['text_success'] = 'Éxito: ¡Has modificado el total de los impuestos!';
$_['text_edit'] = 'Editar total de impuestos';
$_['entry_status'] = 'Estado';
$_['entry_sort_order'] = 'Orden';
$_['error_permission'] = 'Aviso: ¡No tienes permiso para modificar el total de impuestos!';
