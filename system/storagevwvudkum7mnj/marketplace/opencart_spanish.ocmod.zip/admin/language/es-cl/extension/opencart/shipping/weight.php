<?php

$_['heading_title'] = 'Envío basado en peso';
$_['text_extension'] = 'Extensiones';
$_['text_success'] = 'Éxito: ¡Has modificado el envío basado en peso!';
$_['text_edit'] = 'Editar envío basado en peso';
$_['entry_rate'] = 'Tasas';
$_['entry_tax_class'] = 'Tipo de impuesto';
$_['entry_geo_zone'] = 'Zona geográfica';
$_['entry_status'] = 'Estado';
$_['entry_sort_order'] = 'Orden';
$_['help_rate'] = 'Ejemplo: 5:10.00,7:12.00 Peso:Costo,Peso:Costo, etc..';
$_['error_permission'] = 'Aviso: ¡No tienes permiso para modificar el envío basado en peso!';
