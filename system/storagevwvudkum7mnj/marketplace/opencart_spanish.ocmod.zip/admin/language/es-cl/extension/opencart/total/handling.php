<?php

$_['heading_title'] = 'Tasa de manejo';
$_['text_extension'] = 'Extensiones';
$_['text_success'] = 'Éxito: ¡Has modificado el total del costo de manejo!';
$_['text_edit'] = 'Editar total de la tasa de manejo';
$_['entry_total'] = 'Total del pedido';
$_['entry_fee'] = 'Cargo';
$_['entry_tax_class'] = 'Tipo de impuesto';
$_['entry_status'] = 'Estado';
$_['entry_sort_order'] = 'Orden';
$_['help_total'] = 'El pago total que el pedido debe alcanzar antes de que este total de pedidos llegue a activarse.';
$_['error_permission'] = 'Aviso: ¡No tienes permiso para modificar el total de gastos de manejo!';
