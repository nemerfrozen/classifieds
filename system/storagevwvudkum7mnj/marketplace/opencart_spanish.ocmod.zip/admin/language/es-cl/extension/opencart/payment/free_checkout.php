<?php

$_['heading_title'] = 'Compra gratis';
$_['text_extension'] = 'Extensiones';
$_['text_success'] = 'Éxito: ¡Has modificado el módulo de pagos de compra gratis!';
$_['text_edit'] = 'Editar libre de pago';
$_['entry_order_status'] = 'Estado del pedido';
$_['entry_status'] = 'Estado';
$_['entry_sort_order'] = 'Orden';
$_['error_permission'] = 'Aviso: ¡No tienes permiso para modificar el pago compra gratis!';
