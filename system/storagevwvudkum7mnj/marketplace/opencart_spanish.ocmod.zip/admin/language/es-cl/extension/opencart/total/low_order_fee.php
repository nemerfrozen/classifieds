<?php

$_['heading_title'] = 'Cargo por pedido pequeño';
$_['text_extension'] = 'Extensiones';
$_['text_success'] = 'Éxito: ¡Has modificado el total de cargo por pedido bajo!';
$_['text_edit'] = 'Editar total de cargo por pedido pequeño';
$_['entry_total'] = 'Total del pedido';
$_['entry_fee'] = 'Cargo';
$_['entry_tax_class'] = 'Tipo de impuesto';
$_['entry_status'] = 'Estado';
$_['entry_sort_order'] = 'Orden';
$_['help_total'] = 'El pago total que el pedido debe alcanzar antes de que este total de pedido se desactive.';
$_['error_permission'] = 'Aviso: ¡No tienes permiso para modificar el total del cargo por pedido pequeño!';
