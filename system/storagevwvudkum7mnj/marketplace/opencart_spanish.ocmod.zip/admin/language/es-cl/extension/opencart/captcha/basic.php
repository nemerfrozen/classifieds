<?php

$_['heading_title'] = 'Basic Captcha';
$_['text_extension'] = 'Extensiones';
$_['text_success'] = 'Éxito: ¡Has modificado Basic Captcha!';
$_['text_edit'] = 'Editar Basic Captcha';
$_['entry_status'] = 'Estado';
$_['error_permission'] = 'Aviso: ¡No tienes permiso para modificar el módulo de Basic Captcha!';
