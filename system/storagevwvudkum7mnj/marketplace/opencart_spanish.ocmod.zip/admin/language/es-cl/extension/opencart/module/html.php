<?php

$_['heading_title'] = 'Contenido en HTML';
$_['text_extension'] = 'Extensiones';
$_['text_success'] = 'Éxito: ¡Has modificado el módulo de contenido HTML!';
$_['text_edit'] = 'Editar módulo de contenido HTML';
$_['entry_name'] = 'Nombre de módulo';
$_['entry_title'] = 'Título del encabezado';
$_['entry_description'] = 'Descripción';
$_['entry_status'] = 'Estado';
$_['error_permission'] = 'Aviso: ¡No tienes permiso para modificar el módulo de contenido HTML!';
$_['error_name'] = '¡El nombre de módulo debe tener entre 3 y 64 caracteres!';
