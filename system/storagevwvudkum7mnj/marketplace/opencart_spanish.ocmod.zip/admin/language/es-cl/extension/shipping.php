<?php

$_['heading_title'] = 'Envío';
$_['text_success'] = 'Éxito: ¡Has modificado el envío!';
$_['text_list'] = 'Lista de compras';
$_['column_name'] = 'Método de envío';
$_['column_status'] = 'Estado';
$_['column_sort_order'] = 'Orden';
$_['column_action'] = 'Acción';
$_['error_permission'] = 'Aviso: ¡No tienes permiso para modificar los envíos!';
$_['error_extension'] = 'Aviso: ¡La extensión no existe!';
