<?php

$_['heading_title'] = 'Promoción';
