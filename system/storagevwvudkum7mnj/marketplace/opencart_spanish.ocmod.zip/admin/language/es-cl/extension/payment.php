<?php

$_['heading_title'] = 'Pagos';
$_['text_success'] = 'Éxito: ¡Has modificado los pagos!';
$_['text_list'] = 'Lista de pagos';
$_['column_name'] = 'Método de pago';
$_['column_vendor'] = 'Vendedor';
$_['column_status'] = 'Estado';
$_['column_sort_order'] = 'Orden';
$_['column_action'] = 'Acción';
$_['error_permission'] = 'Aviso: ¡No tienes permiso para modificar los pagos!';
$_['error_extension'] = 'Aviso: ¡La extensión no existe!';
