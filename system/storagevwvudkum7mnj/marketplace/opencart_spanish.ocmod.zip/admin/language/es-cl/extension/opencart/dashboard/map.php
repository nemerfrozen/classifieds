<?php

$_['heading_title'] = 'Mapa mundial';
$_['text_extension'] = 'Extensiones';
$_['text_success'] = 'Éxito: ¡Has modificado el mapa del panel!';
$_['text_edit'] = 'Editar mapa del panel';
$_['text_order'] = 'Pedidos';
$_['text_sale'] = 'Ventas';
$_['entry_status'] = 'Estado';
$_['entry_sort_order'] = 'Orden';
$_['entry_width'] = 'Ancho';
$_['error_permission'] = 'Aviso: ¡No tienes permiso para modificar el panel de control de mapa!';
