<?php

$_['heading_title'] = 'Informe de cupones';
$_['text_extension'] = 'Extensiones';
$_['text_edit'] = 'Editar informe de cupones';
$_['text_success'] = 'Éxito: ¡Has modificado el informe de cupones!';
$_['text_filter'] = 'Filtrar';
$_['column_name'] = 'Nombre de cupón';
$_['column_code'] = 'Código';
$_['column_orders'] = 'Pedidos';
$_['column_total'] = 'Total';
$_['column_action'] = 'Acción';
$_['entry_date_start'] = 'Fecha de inicio';
$_['entry_date_end'] = 'Fecha de fin';
$_['entry_status'] = 'Estado';
$_['entry_sort_order'] = 'Orden';
$_['error_permission'] = 'Aviso: ¡No tienes permiso para modificar el informe de cupones!';
