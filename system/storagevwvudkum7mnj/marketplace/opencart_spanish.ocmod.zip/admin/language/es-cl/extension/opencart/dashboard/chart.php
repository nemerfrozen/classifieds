<?php

$_['heading_title'] = 'Analítica de ventas';
$_['text_extension'] = 'Extensiones';
$_['text_success'] = 'Éxito: ¡Has modificado el gráfico del tablero!';
$_['text_edit'] = 'Editar gráfico del panel';
$_['text_order'] = 'Pedidos';
$_['text_customer'] = 'Clientes';
$_['text_day'] = 'Hoy';
$_['text_week'] = 'Semana';
$_['text_month'] = 'Mes';
$_['text_year'] = 'Año';
$_['entry_status'] = 'Estado';
$_['entry_sort_order'] = 'Orden';
$_['entry_width'] = 'Ancho';
$_['error_permission'] = 'Aviso: ¡No tienes permiso para modificar el panel de control de gráfico!';
