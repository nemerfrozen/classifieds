<?php

$_['heading_title'] = 'Últimos pedidos';
$_['text_extension'] = 'Extensiones';
$_['text_success'] = 'Éxito: ¡Has modificado el panel de control de pedidos recientes!';
$_['text_edit'] = 'Editar panel de control de pedidos recientes';
$_['column_order_id'] = 'ID de pedido';
$_['column_customer'] = 'Cliente';
$_['column_status'] = 'Estado';
$_['column_total'] = 'Total';
$_['column_date_added'] = 'Fecha de alta';
$_['column_action'] = 'Acción';
$_['entry_status'] = 'Estado';
$_['entry_sort_order'] = 'Orden';
$_['entry_width'] = 'Ancho';
$_['error_permission'] = 'Aviso: ¡No tienes permiso para modificar el panel de control de pedidos recientes!';
