<?php

$_['heading_title'] = 'Total';
$_['text_extension'] = 'Extensiones';
$_['text_success'] = 'Éxito: ¡Has modificado los totales finales!';
$_['text_edit'] = 'Editar total final';
$_['entry_status'] = 'Estado';
$_['entry_sort_order'] = 'Orden';
$_['error_permission'] = 'Aviso: ¡No tienes permiso para modificar los totales finales!';
