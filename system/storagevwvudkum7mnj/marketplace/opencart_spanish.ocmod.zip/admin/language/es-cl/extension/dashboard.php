<?php

$_['heading_title'] = 'Panel de control';
$_['text_success'] = 'Éxito: ¡Has modificado los paneles de control!';
$_['text_list'] = 'Lista de paneles';
$_['column_name'] = 'Nombre de panel';
$_['column_width'] = 'Ancho';
$_['column_status'] = 'Estado';
$_['column_sort_order'] = 'Orden';
$_['column_action'] = 'Acción';
$_['error_permission'] = 'Aviso: ¡No tienes permiso para modificar los paneles de control!';
$_['error_extension'] = 'Aviso: ¡La extensión no existe!';
