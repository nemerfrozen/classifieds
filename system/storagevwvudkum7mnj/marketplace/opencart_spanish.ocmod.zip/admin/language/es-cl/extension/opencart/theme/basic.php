<?php

$_['heading_title'] = 'Tema predeterminado de la tienda';
$_['text_extension'] = 'Extensiones';
$_['text_success'] = 'Éxito: ¡Has modificado el tema predeterminado de la tienda!';
$_['text_edit'] = 'Editar tema predeterminado de la tienda';
$_['entry_status'] = 'Estado';
$_['error_permission'] = 'Aviso: ¡No tienes permiso para modificar el tema predeterminado de la tienda!';
