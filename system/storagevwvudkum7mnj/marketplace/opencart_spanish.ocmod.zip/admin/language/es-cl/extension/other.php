<?php

$_['heading_title'] = 'Otro';
$_['text_success'] = 'Éxito: ¡Has modificado la extensión otros!';
$_['text_list'] = 'Otra lista';
$_['column_name'] = 'Otro nombre';
$_['column_status'] = 'Estado';
$_['column_action'] = 'Acción';
$_['error_permission'] = 'Aviso: ¡No tienes permiso para modificar otra extensión!';
$_['error_extension'] = 'Aviso: ¡La extensión no existe!';
