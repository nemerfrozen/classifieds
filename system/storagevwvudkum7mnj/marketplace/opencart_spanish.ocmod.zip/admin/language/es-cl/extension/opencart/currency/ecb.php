<?php

$_['heading_title'] = 'Convertidor de divisas del Banco Central Europeo';
$_['text_extension'] = 'Extensiones';
$_['text_success'] = 'Éxito: ¡Has modificado el conversor de divisas del Banco Central Europeo!';
$_['text_edit'] = 'Editar Banco Central Europeo';
$_['text_support'] = 'Esta extensión requiere que la divisa EUR esté disponible como opción de divisa.';
$_['entry_status'] = 'Estado';
$_['error_permission'] = 'Aviso: ¡No tienes permiso para modificar el conversor de divisas del Banco Central Europeo!';
