<?php

$_['heading_title'] = 'Notificaciones';
$_['text_success'] = 'Éxito: ¡Has modificado las notificaciones!';
$_['text_list'] = 'Lista de notificaciones';
$_['column_message'] = 'Mensaje';
$_['column_action'] = 'Acción';
$_['error_permission'] = 'Aviso: ¡No tienes permiso para modificar notificaciones!';
