<?php

$_['heading_title'] = 'Registro de errores';
$_['text_success'] = 'Éxito: ¡Has limpiado exitosamente tu registro de errores!';
$_['text_list'] = 'Lista de errores';
$_['error_permission'] = 'Aviso: ¡No tienes permiso para borrar el registro de errores!';
$_['error_file'] = 'Aviso: ¡No se pudo encontrar el archivo %s!';
$_['error_size'] = 'Aviso: ¡El archivo de registro de errores %s es %s!';
$_['error_empty'] = 'Aviso: ¡El archivo del registro de eventos %s está vacío!';
