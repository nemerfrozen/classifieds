<?php

$_['text_project'] = 'Sitio web del proyecto';
$_['text_documentation'] = 'Documentación';
$_['text_support'] = 'Foros de soporte';
$_['text_footer'] = '<a href="http://www.opencart.com">OpenCart</a> &copy; 2009-2024 Todos los derechos reservados.';
