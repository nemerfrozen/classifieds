<?php

$_['text_name'] = 'Español (Chile)';
$_['text_loading'] = 'Cargando...';
$_['button_continue'] = 'Continuar';
$_['button_back'] = 'Volver';
$_['error_exception'] = 'Código de error(%s): %s en %s en la línea %s';
