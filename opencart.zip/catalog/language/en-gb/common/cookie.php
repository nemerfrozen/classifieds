<?php
// Text
$_['text_success'] = 'Thank you for letting us know your choice!';
$_['text_cookie']  = 'This website uses cookies. For more information <a href="%s" class="alert-link modal-link">click here</a>.';

// Button
$_['button_agree']    = 'Yes, that\'s fine!';
$_['button_disagree'] = 'No Thanks!';