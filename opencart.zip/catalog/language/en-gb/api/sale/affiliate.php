<?php
// Text
$_['text_success']    = 'Success: Affiliate commission will be appliyed to this order!';
$_['text_remove']     = 'Success: Your affiliate commission has been removed!';

// Error
$_['error_affiliate'] = 'Warning: Affiliate could not be found!';