<?php
// Text
$_['text_subject']  = '%s - GDPR Export/Deletion Request!';
$_['text_export']   = 'Export Data Request';
$_['text_remove']   = 'Account Deletion Request';
$_['text_gdpr']     = 'A GDPR request from this email address, To confirm this action please click on the link below:';
$_['text_ip']       = 'The IP used to make this request was:';
$_['text_contact']  = 'If you did not make this request please contact the store owner here:';
$_['text_thanks']   = 'Thanks,';
$_['text_ignore']   = 'If you did not created this request, please ignore this email.';

// Button
$_['button_export'] = 'I confirm export my data';
$_['button_remove'] = 'I confirm delete my account';
