<?php
// Heading
$_['heading_title'] = 'GDPR Success';

// Text
$_['text_account']  = 'Account';
$_['text_export']   = 'A request to export your account data has been received.';
$_['text_remove']   = 'GDPR account deletion requests will process after <strong>%s days</strong> so any chargebacks, refunds or fraud detection can be processed.';
